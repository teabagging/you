export default function SongName ({ songName }) {
  return (
    <p className='pr-5 whitespace-nowrap'>{songName}</p>
  )
}
